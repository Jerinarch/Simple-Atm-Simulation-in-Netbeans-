/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simpleatmsimulation;

/**
 *
 * @author jerin
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
public class Simpleatmsimulation {
    private static String userCardNumber = null; 
    private static String userPIN = null;  
    private static double balance = 1000.00;  
    private static JFrame createAccountFrame, loginFrame, transactionFrame;
    private static Random random = new Random(); 
    private static ArrayList<String> transactionHistory = new ArrayList<>();
    private static Color currentColor = Color.WHITE;  
    public static void main(String[] args) {
        showCreateAccountFrame();
    }

    
    private static void showCreateAccountFrame() {
        createAccountFrame = new JFrame("ACCOUNT CREATION");
        createAccountFrame.setSize(400, 300);
        createAccountFrame.setLayout(null);  
        createAccountFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addMenuBar(createAccountFrame);  
        createAccountFrame.getContentPane().setBackground(currentColor); 

       
        JLabel welcomeLabel = new JLabel(" RAJ ATM - Create Account");
        welcomeLabel.setBounds(100, 20, 250, 25);
        createAccountFrame.add(welcomeLabel);

     
        JLabel cardNumberLabel = new JLabel("Enter your Bank Card Number:");
        cardNumberLabel.setBounds(50, 60, 200, 25);
        createAccountFrame.add(cardNumberLabel);

        JTextField cardNumberField = new JTextField(10);
        cardNumberField.setBounds(250, 60, 100, 25);
        createAccountFrame.add(cardNumberField);

        JLabel setPINLabel = new JLabel("Set your PIN:");
        setPINLabel.setBounds(50, 100, 200, 25);
        createAccountFrame.add(setPINLabel);

        JPasswordField setPINField = new JPasswordField(10);
        setPINField.setBounds(250, 100, 100, 25);
        createAccountFrame.add(setPINField);

        // Button to Set PIN
        JButton setPINButton = new JButton("Set PIN");
        setPINButton.setBounds(150, 150, 100, 25);
        createAccountFrame.add(setPINButton);

        setPINButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cardNumber = cardNumberField.getText();
                String pin = String.valueOf(setPINField.getPassword());  

                if (!cardNumber.isEmpty() && !pin.isEmpty()) {
                    userCardNumber = cardNumber; 
                    userPIN = pin;  
                    JOptionPane.showMessageDialog(createAccountFrame, "Account created successfully! Please login.");
                    createAccountFrame.setVisible(false);
                    showLoginFrame();  
                } else {
                    JOptionPane.showMessageDialog(createAccountFrame, "Card Number and PIN cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        createAccountFrame.setVisible(true);
    }

   
    private static void showLoginFrame() {
        loginFrame = new JFrame("ATM Login");
        loginFrame.setSize(400, 300);
        loginFrame.setLayout(null);  
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addMenuBar(loginFrame);  
        loginFrame.getContentPane().setBackground(currentColor);

       
        JLabel welcomeLabel = new JLabel("RAJ ATM - Login");
        welcomeLabel.setBounds(125, 20, 250, 25);
        loginFrame.add(welcomeLabel);

      
        JLabel cardNumberLabel = new JLabel("Enter your Bank Card Number:");
        cardNumberLabel.setBounds(50, 60, 200, 25);
        loginFrame.add(cardNumberLabel);

        JTextField cardNumberField = new JTextField(10);
        cardNumberField.setBounds(250, 60, 100, 25);
        loginFrame.add(cardNumberField);

        JLabel pinLabel = new JLabel("Enter your PIN:");
        pinLabel.setBounds(50, 100, 200, 25);
        loginFrame.add(pinLabel);

        JPasswordField pinField = new JPasswordField(10);
        pinField.setBounds(250, 100, 100, 25);
        loginFrame.add(pinField);

  
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(150, 150, 100, 25);
        loginFrame.add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cardNumber = cardNumberField.getText();
                String pin = String.valueOf(pinField.getPassword());

                if (userCardNumber.equals(cardNumber) && userPIN.equals(pin)) {
                    JOptionPane.showMessageDialog(loginFrame, "Login successful!");
                    loginFrame.setVisible(false);  
                    showTransactionFrame(); 
                } else {
                    JOptionPane.showMessageDialog(loginFrame, "Invalid card number or PIN!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        loginFrame.setVisible(true);
    }


    private static void showTransactionFrame() {
        transactionFrame = new JFrame("ATM MENU");
        transactionFrame.setSize(400, 350);
        transactionFrame.setLayout(null); 
        transactionFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addMenuBar(transactionFrame);  
        transactionFrame.getContentPane().setBackground(currentColor);  

        
        JLabel welcomeLabel = new JLabel("RAJ ATM - MENU");
        welcomeLabel.setBounds(125, 20, 250, 25);
        transactionFrame.add(welcomeLabel);

       
        JButton depositButton = new JButton("Deposit");
        depositButton.setBounds(50, 70, 100, 25);
        transactionFrame.add(depositButton);

        JButton withdrawButton = new JButton("Withdraw");
        withdrawButton.setBounds(200, 70, 100, 25);
        transactionFrame.add(withdrawButton);

        JButton balanceButton = new JButton("Check Balance");
        balanceButton.setBounds(50, 120, 125, 25);
        transactionFrame.add(balanceButton);

        JButton changePINButton = new JButton("Change PIN");
        changePINButton.setBounds(175, 120, 125, 25);
        transactionFrame.add(changePINButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(125, 170, 100, 25);
        transactionFrame.add(logoutButton);
        
        JButton historyButton = new JButton("Transaction History");
        historyButton.setBounds(100, 220, 150, 25);
        transactionFrame.add(historyButton);

        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String amountStr = JOptionPane.showInputDialog(transactionFrame, "Enter amount to deposit:");
                if (amountStr != null && !amountStr.isEmpty()) {
                    
                    double amount = Double.parseDouble(amountStr);
                    if(amount<0)
                       JOptionPane.showMessageDialog(transactionFrame, " Deposit Amount can't be negative!", "Error", JOptionPane.ERROR_MESSAGE);
                    if(amount>499){
                    balance += amount;
                    JOptionPane.showMessageDialog(transactionFrame, "Deposited " + amount);
                    transactionHistory.add("Deposited: " + amount + " | Balance: " + balance);
                }
                    else{
                     JOptionPane.showMessageDialog(transactionFrame, "Minimum Deposit is 500", "Error", JOptionPane.ERROR_MESSAGE);   
                    }   
               }
            }
        });

        withdrawButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String amountStr = JOptionPane.showInputDialog(transactionFrame, "Enter amount to withdraw:");
        if (amountStr != null && !amountStr.isEmpty()) {
            double amount = Double.parseDouble(amountStr);
            if (amount < 0) {
                JOptionPane.showMessageDialog(transactionFrame, "Amount can't be negative!", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (balance >= amount) {
                balance -= amount;
                JOptionPane.showMessageDialog(transactionFrame, "Withdrew " + amount);
                transactionHistory.add("Withdrew: " + amount + " | Balance: " + balance); 
            } else {
                JOptionPane.showMessageDialog(transactionFrame, "Insufficient funds!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
});

        balanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(transactionFrame, "Current Balance: " + balance);
            }
        });

        changePINButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newPin = JOptionPane.showInputDialog(transactionFrame, "Enter new PIN:");
                if (newPin != null && !newPin.isEmpty()) {
                    userPIN = newPin;  // Update the PIN
                    JOptionPane.showMessageDialog(transactionFrame, "PIN changed successfully!");
                } else {
                    JOptionPane.showMessageDialog(transactionFrame, "New PIN cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                transactionFrame.setVisible(false);
                showLoginFrame();  // Return to login frame
            }
        });
        
          historyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show transaction history
                if (transactionHistory.isEmpty()) {
                    JOptionPane.showMessageDialog(transactionFrame, "No transactions available.");
                } else {
                    StringBuilder history = new StringBuilder();
                    for (String record : transactionHistory) {
                        history.append(record).append("\n");
                    }
                    JOptionPane.showMessageDialog(transactionFrame, history.toString(), "Transaction History", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        transactionFrame.setVisible(true);
    }

    // Method to add a menu bar to a given frame
    private static void addMenuBar(JFrame frame) {
        JMenuBar menuBar = new JMenuBar();

        
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        fileMenu.add(exitItem);

     
        JMenuItem logoutItem = new JMenuItem("Log Out");
        logoutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Logged out successfully!");
                frame.setVisible(false);
                showLoginFrame();  
            }
        });
        fileMenu.add(logoutItem);

       
        JMenuItem createAccountItem = new JMenuItem("Create Account");
        createAccountItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                showCreateAccountFrame(); 
            }
        });
        fileMenu.add(createAccountItem);

 
        JMenu viewMenu = new JMenu("Theme");
        JMenuItem lightThemeItem = new JMenuItem("Light Theme");
        lightThemeItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentColor = Color.WHITE;  // Set to light color
                frame.getContentPane().setBackground(currentColor);
                frame.getContentPane().setForeground(Color.BLACK);  // Set text color
            }
        });
        JMenuItem DarkThemeItem = new JMenuItem("Dark Theme");
        DarkThemeItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentColor = Color.BLACK;  // Set to light color
                frame.getContentPane().setBackground(currentColor);
                frame.getContentPane().setForeground(Color.GRAY);  // Set text color
            }
        });
        JMenuItem randomColorThemeItem = new JMenuItem("Random Color Theme");
        randomColorThemeItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentColor = getRandomColor();  // Generate random color
                frame.getContentPane().setBackground(currentColor);
                frame.getContentPane().setForeground(Color.BLACK);  // Set text color
            }
        });
        
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Display "About" dialog when clicked
                JOptionPane.showMessageDialog(frame,
                        "RAJ ATM Software v1.0","About RAJ ATM",JOptionPane.INFORMATION_MESSAGE);
            }
        });
        helpMenu.add(aboutItem);


        viewMenu.add(lightThemeItem);
        viewMenu.add(DarkThemeItem);
        viewMenu.add(randomColorThemeItem);

        
        menuBar.add(fileMenu);
        menuBar.add(viewMenu);
        menuBar.add(helpMenu);

        
        frame.setJMenuBar(menuBar);
    }

   
    private static Color getRandomColor() {
        float r = random.nextFloat();
        float g = random.nextFloat();
        float b = random.nextFloat();
        return new Color(r, g, b);
    }

    }
    

